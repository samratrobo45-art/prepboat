# PrepBoat — Starter Website (React + Vite + Supabase + Vercel)

## Step 1: Install & Run Locally
1. Unzip this folder and open it in VS Code (or your terminal).
2. Run `npm install`
3. Copy `.env.example` to `.env` and add your Supabase Project URL and `anon` public key.
4. Run `npm run dev` to preview locally.

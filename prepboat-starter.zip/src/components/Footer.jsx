import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer
      style={{
        borderTop: '1px solid var(--border-light)',
        padding: '36px 0',
        marginTop: '80px',
        color: 'var(--text-muted)',
        fontSize: '0.875rem',
      }}
    >
      <div
        className="container"
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '16px',
        }}
      >
        <div>
          <strong style={{ color: 'var(--text-charcoal)' }}>PrepBoat</strong> — Your Journey to Exam Success.
        </div>
        <div style={{ display: 'flex', gap: '20px' }}>
          <Link to="/">Home</Link>
          <Link to="/login">Student Login</Link>
          <Link to="/admin/login">Admin Portal</Link>
        </div>
      </div>
    </footer>
  );
}

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Compass, LogOut, ShieldCheck, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await signOut();
    navigate('/');
  }

  return (
    <header
      style={{
        borderBottom: '1px solid var(--border-light)',
        backgroundColor: 'rgba(250, 248, 245, 0.92)',
        position: 'sticky',
        top: 0,
        zIndex: 20,
        backdropFilter: 'blur(8px)',
      }}
    >
      <div
        className="container"
        style={{
          height: '72px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Link
          to="/"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            fontWeight: 600,
            fontSize: '1.2rem',
            color: 'var(--accent-forest)',
          }}
        >
          <Compass size={24} strokeWidth={2.2} />
          <span>PrepBoat</span>
        </Link>

        <nav style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {!user ? (
            <>
              <Link to="/admin/login" className="btn btn-ghost" style={{ fontSize: '0.85rem' }}>
                Admin
              </Link>
              <Link to="/login" className="btn btn-outline">
                Log in
              </Link>
              <Link to="/signup" className="btn btn-primary">
                Start Practising
              </Link>
            </>
          ) : (
            <>
              {isAdmin ? (
                <Link to="/admin" className="btn btn-ghost">
                  <ShieldCheck size={17} />
                  Admin Panel
                </Link>
              ) : (
                <Link to="/dashboard" className="btn btn-ghost">
                  <User size={17} />
                  Dashboard
                </Link>
              )}
              <button onClick={handleLogout} className="btn btn-outline">
                <LogOut size={16} />
                Sign out
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}

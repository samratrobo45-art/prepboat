import React, { useState } from 'react';
import { BookOpen, FileText, PlayCircle, Award } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const SUBJECTS = [
  {
    id: 'Mathematics',
    title: 'Mathematics',
    description: 'Algebra, Geometry, Trigonometry, Mensuration & Statistics',
  },
  {
    id: 'Science',
    title: 'Science',
    description: 'Physics, Chemistry & Biology concepts and numericals',
  },
  {
    id: 'Social Science',
    title: 'Social Science',
    description: 'History, Geography, Civics & Economics',
  },
];

const CATEGORIES = ['All', 'PYQ', 'Important', 'School Exam', 'Sample Paper'];

export default function StudentDashboardPage() {
  const { user, profile } = useAuth();

  const [selectedClass, setSelectedClass] = useState(
    profile?.class_level ? String(profile.class_level) : '10'
  );
  const [selectedBoard, setSelectedBoard] = useState(profile?.board || 'CBSE');
  const [selectedSubject, setSelectedSubject] = useState('Mathematics');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [questionCount, setQuestionCount] = useState(10);
  const [timedMode, setTimedMode] = useState(true);

  const displayName =
    profile?.full_name || user?.user_metadata?.full_name || user?.email?.split('@')[0] || 'Student';

  return (
    <div className="container" style={{ padding: '44px 24px' }}>
      {/* Welcome Header */}
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'flex-end',
          gap: '16px',
          marginBottom: '36px',
        }}
      >
        <div>
          <span className="badge" style={{ marginBottom: '10px' }}>
            Student Workspace
          </span>
          <h1 className="serif-heading" style={{ fontSize: '2.1rem' }}>
            Welcome, {displayName}
          </h1>
          <p style={{ color: 'var(--text-muted)', marginTop: '4px' }}>
            Choose your class, board, and subject to begin a focused practice session.
          </p>
        </div>

        {/* Class & Board Selector */}
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <div>
            <label className="form-label" style={{ display: 'block', marginBottom: '4px' }}>
              Class
            </label>
            <select
              className="form-select"
              style={{ minWidth: '125px' }}
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
            >
              <option value="8">Class 8</option>
              <option value="9">Class 9</option>
              <option value="10">Class 10</option>
            </select>
          </div>

          <div>
            <label className="form-label" style={{ display: 'block', marginBottom: '4px' }}>
              Board
            </label>
            <select
              className="form-select"
              style={{ minWidth: '125px' }}
              value={selectedBoard}
              onChange={(e) => setSelectedBoard(e.target.value)}
            >
              <option value="CBSE">CBSE</option>
              <option value="ICSE">ICSE</option>
            </select>
          </div>
        </div>
      </div>

      {/* Progress Overview Cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))',
          gap: '16px',
          marginBottom: '40px',
        }}
      >
        <div className="card" style={{ padding: '18px 20px' }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Active Track</div>
          <div style={{ fontSize: '1.25rem', fontWeight: 600, marginTop: '4px' }}>
            Class {selectedClass} • {selectedBoard}
          </div>
        </div>

        <div className="card" style={{ padding: '18px 20px' }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Tests Completed</div>
          <div style={{ fontSize: '1.25rem', fontWeight: 600, marginTop: '4px' }}>0</div>
        </div>

        <div className="card" style={{ padding: '18px 20px' }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Average Accuracy</div>
          <div style={{ fontSize: '1.25rem', fontWeight: 600, marginTop: '4px' }}>—</div>
        </div>
      </div>

      {/* Step 1: Select Subject */}
      <h2 className="serif-heading" style={{ fontSize: '1.45rem', marginBottom: '16px' }}>
        1. Select Subject
      </h2>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
          gap: '18px',
          marginBottom: '40px',
        }}
      >
        {SUBJECTS.map((subj) => {
          const active = selectedSubject === subj.id;
          return (
            <button
              key={subj.id}
              type="button"
              onClick={() => setSelectedSubject(subj.id)}
              className="card"
              style={{
                textAlign: 'left',
                cursor: 'pointer',
                borderColor: active ? 'var(--accent-forest)' : 'var(--border-light)',
                backgroundColor: active ? 'var(--accent-forest-soft)' : 'var(--bg-surface)',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <BookOpen size={20} color="var(--accent-forest)" />
                {active && <span className="badge">Selected</span>}
              </div>
              <div style={{ fontWeight: 600, fontSize: '1.1rem', marginBottom: '4px' }}>
                {subj.title}
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                {subj.description}
              </div>
            </button>
          );
        })}
      </div>

      {/* Step 2: Configure Practice / Test Session */}
      <h2 className="serif-heading" style={{ fontSize: '1.45rem', marginBottom: '16px' }}>
        2. Configure Practice Session
      </h2>
      <div className="card" style={{ padding: '28px' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: '20px',
            marginBottom: '24px',
          }}
        >
          <div>
            <label className="form-label" style={{ display: 'block', marginBottom: '6px' }}>
              Question Category
            </label>
            <select
              className="form-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat === 'All' ? 'All Categories' : cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="form-label" style={{ display: 'block', marginBottom: '6px' }}>
              Test Length
            </label>
            <select
              className="form-select"
              value={questionCount}
              onChange={(e) => setQuestionCount(Number(e.target.value))}
            >
              <option value={10}>10 Questions (Quick Drill)</option>
              <option value={20}>20 Questions (Standard Test)</option>
              <option value={30}>30 Questions (Full Practice)</option>
            </select>
          </div>

          <div>
            <label className="form-label" style={{ display: 'block', marginBottom: '6px' }}>
              Timer Option
            </label>
            <select
              className="form-select"
              value={timedMode ? 'timed' : 'untimed'}
              onChange={(e) => setTimedMode(e.target.value === 'timed')}
            >
              <option value="timed">Timed Exam Mode</option>
              <option value="untimed">Untimed Practice Mode</option>
            </select>
          </div>
        </div>

        <div
          style={{
            borderTop: '1px solid var(--border-light)',
            paddingTop: '20px',
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '14px',
          }}
        >
          <div style={{ fontSize: '0.92rem', color: 'var(--text-muted)' }}>
            Ready: <strong style={{ color: 'var(--text-charcoal)' }}>Class {selectedClass} {selectedBoard} {selectedSubject}</strong> • {questionCount} Questions ({timedMode ? 'Timed' : 'Untimed'})
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button type="button" className="btn btn-outline" disabled title="Will be wired in the Question Bank step">
              <FileText size={17} />
              Browse Question Bank
            </button>
            <button type="button" className="btn btn-primary" disabled title="Will be wired in the Test Engine step">
              <PlayCircle size={17} />
              Start Test (Next Step)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

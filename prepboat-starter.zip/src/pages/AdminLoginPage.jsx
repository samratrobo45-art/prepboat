import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../lib/supabaseClient';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!isSupabaseConfigured) {
      setError('Supabase keys are not configured in .env yet.');
      return;
    }

    setLoading(true);
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    if (signInError) {
      setLoading(false);
      setError(signInError.message);
      return;
    }

    // Verify admin status via your existing security-definer RPC
    const { data: isAdmin, error: rpcError } = await supabase.rpc('is_prepboat_admin');
    setLoading(false);

    if (rpcError || !isAdmin) {
      await supabase.auth.signOut();
      setError('Access denied. This account is not listed in admin_users.');
      return;
    }

    navigate('/admin');
  }

  return (
    <div className="container" style={{ maxWidth: '440px', padding: '72px 24px' }}>
      <div className="card" style={{ padding: '32px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent-forest)', marginBottom: '12px' }}>
          <ShieldCheck size={22} />
          <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>PrepBoat Admin</span>
        </div>
        <h1 className="serif-heading" style={{ fontSize: '1.8rem', marginBottom: '8px' }}>
          Administrator Sign In
        </h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', marginBottom: '24px' }}>
          Restricted to authorized PrepBoat content administrators.
        </p>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label" htmlFor="adminEmail">Admin Email</label>
            <input
              id="adminEmail"
              type="email"
              className="form-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-group" style={{ marginBottom: '22px' }}>
            <label className="form-label" htmlFor="adminPassword">Password</label>
            <input
              id="adminPassword"
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Verifying...' : 'Sign In as Admin'}
          </button>
        </form>
      </div>
    </div>
  );
}

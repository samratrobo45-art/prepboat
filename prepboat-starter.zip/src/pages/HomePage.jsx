import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, CheckCircle2, Clock, BarChart3 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div>
      {/* Hero Section */}
      <section style={{ padding: '88px 0 72px' }}>
        <div className="container" style={{ maxWidth: '820px', textAlign: 'center' }}>
          <span className="badge" style={{ marginBottom: '20px' }}>
            CBSE &amp; ICSE • Classes 8, 9 &amp; 10
          </span>
          <h1
            className="serif-heading"
            style={{
              fontSize: 'clamp(2.4rem, 5vw, 3.5rem)',
              color: 'var(--text-charcoal)',
              marginBottom: '20px',
            }}
          >
            Your Journey to Exam Success.
          </h1>
          <p
            style={{
              fontSize: '1.125rem',
              color: 'var(--text-muted)',
              maxWidth: '620px',
              margin: '0 auto 36px',
            }}
          >
            Learn. Practice. Succeed. Structured chapter-wise question banks, previous year
            papers, and focused mock tests in Mathematics, Science, and Social Science.
          </p>

          <div style={{ display: 'flex', gap: '14px', justifyContent: 'center', flexWrap: 'wrap' }}>
            {user ? (
              <Link to="/dashboard" className="btn btn-primary" style={{ padding: '13px 26px' }}>
                Go to Student Dashboard
                <ArrowRight size={18} />
              </Link>
            ) : (
              <>
                <Link to="/signup" className="btn btn-primary" style={{ padding: '13px 26px' }}>
                  Create Free Student Account
                  <ArrowRight size={18} />
                </Link>
                <Link to="/login" className="btn btn-outline" style={{ padding: '13px 26px' }}>
                  Sign In to Practise
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Curriculum Coverage */}
      <section style={{ padding: '48px 0' }}>
        <div className="container">
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '24px',
            }}
          >
            <div className="card">
              <div className="badge" style={{ marginBottom: '14px' }}>Classes</div>
              <h3 className="serif-heading" style={{ fontSize: '1.4rem', marginBottom: '8px' }}>
                Class 8, 9 &amp; 10
              </h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
                Foundation-to-board preparation tailored strictly to your class syllabus.
              </p>
            </div>

            <div className="card">
              <div className="badge" style={{ marginBottom: '14px' }}>Boards</div>
              <h3 className="serif-heading" style={{ fontSize: '1.4rem', marginBottom: '8px' }}>
                CBSE &amp; ICSE
              </h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
                Board-aligned question formats including PYQs, school exam papers, and sample tests.
              </p>
            </div>

            <div className="card">
              <div className="badge" style={{ marginBottom: '14px' }}>Core Subjects</div>
              <h3 className="serif-heading" style={{ fontSize: '1.4rem', marginBottom: '8px' }}>
                Maths, Science &amp; Social Science
              </h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
                Topic-by-topic mastery with MCQs, short-answer, and long-answer practice sets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How PrepBoat Works */}
      <section style={{ padding: '56px 0 24px' }}>
        <div className="container">
          <div style={{ marginBottom: '36px', maxWidth: '600px' }}>
            <h2 className="serif-heading" style={{ fontSize: '2rem', marginBottom: '10px' }}>
              Calm, focused exam preparation
            </h2>
            <p style={{ color: 'var(--text-muted)' }}>
              Designed to help students practise consistently without distractions.
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
              gap: '24px',
            }}
          >
            <div style={{ padding: '8px 0' }}>
              <BookOpen size={22} color="var(--accent-forest)" style={{ marginBottom: '12px' }} />
              <h4 style={{ fontSize: '1.05rem', marginBottom: '6px' }}>Curated Question Banks</h4>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
                Filter by PYQs, Important Questions, School Exam sets, and Sample Papers.
              </p>
            </div>

            <div style={{ padding: '8px 0' }}>
              <Clock size={22} color="var(--accent-forest)" style={{ marginBottom: '12px' }} />
              <h4 style={{ fontSize: '1.05rem', marginBottom: '6px' }}>Flexible Topic Tests</h4>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
                Take 10, 20, or 30-question tests with an optional countdown timer.
              </p>
            </div>

            <div style={{ padding: '8px 0' }}>
              <CheckCircle2 size={22} color="var(--accent-forest)" style={{ marginBottom: '12px' }} />
              <h4 style={{ fontSize: '1.05rem', marginBottom: '6px' }}>Step-by-Step Solutions</h4>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
                Review verified answers and detailed explanations right after submitting.
              </p>
            </div>

            <div style={{ padding: '8px 0' }}>
              <BarChart3 size={22} color="var(--accent-forest)" style={{ marginBottom: '12px' }} />
              <h4 style={{ fontSize: '1.05rem', marginBottom: '6px' }}>Progress Tracking</h4>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
                Track completed tests, accuracy trends, and chapters that need revision.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import React from 'react';
import { ShieldCheck, PlusCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function AdminDashboardPage() {
  const { user } = useAuth();

  return (
    <div className="container" style={{ padding: '44px 24px' }}>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '16px',
          marginBottom: '32px',
        }}
      >
        <div>
          <span className="badge" style={{ marginBottom: '8px' }}>
            <ShieldCheck size={14} style={{ marginRight: '6px' }} />
            Verified Admin Session
          </span>
          <h1 className="serif-heading" style={{ fontSize: '2rem' }}>
            Question Bank Management
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
            Signed in as {user?.email}
          </p>
        </div>

        <button type="button" className="btn btn-primary" disabled title="Will be wired in the Admin Question Manager step">
          <PlusCircle size={18} />
          Add New Question (Next Step)
        </button>
      </div>

      <div className="card">
        <p style={{ color: 'var(--text-muted)' }}>
          Admin authentication shell is ready. In the next step, we will connect your existing static admin interface to <code>public.questions</code> so you can add, edit, delete, and publish/unpublish questions by Class, Board, Subject, Chapter, and Topic.
        </p>
      </div>
    </div>
  );
}
